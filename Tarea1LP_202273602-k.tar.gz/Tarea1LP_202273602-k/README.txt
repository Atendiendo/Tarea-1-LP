Miguel Huerta Flores
Rol: 202273602-k

Instrucciones:
    -Coloca los problemas a resolver en un archivo de texto,
    donde cada línea contiene una expresión matemática o un bloque de operaciones.
    -Los nombres predeterminados de los archivos para leer problemas y guardar los
    resultados son respectivamente: "problemas.txt"  "desarrollos.txt"
    -Si se desea correr este programa desde la terminal debes estar en la
    carpeta correspondiente y escribir:
    python calculadora.py problemas.txt resultados.txt